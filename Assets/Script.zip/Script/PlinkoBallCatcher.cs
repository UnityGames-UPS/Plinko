using UnityEngine;
using DG.Tweening;
using TMPro;

public class PlinkoBallCatcher : MonoBehaviour
{
    [Header("Catch Impact Animation")]
    [SerializeField] private float dipAmount = 0.12f;     // Downward movement
    [SerializeField] private float impactDuration = 0.10f;
    [SerializeField] private float settleDuration = 0.16f;
    [SerializeField] private float reversePopScale = 0.92f; // Inward pop (absorb)

    [Header("Multiplier Display (STATIC)")]
    [SerializeField] private TextMeshProUGUI multiplierText;

    private RectTransform rectTransform;
    private float multiplierValue = 1f;

    void Awake()
    {
        rectTransform = GetComponent<RectTransform>();
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (!collision.CompareTag("Ball")) return;

        collision.gameObject.SetActive(false);
        PlayCatchAnimation();
    }

    public void PlayCatchAnimation()
    {
        if (rectTransform == null) return;

        rectTransform.DOKill();

        // Cache exact current state
        Vector3 startPos = rectTransform.localPosition;
        Vector3 startScale = rectTransform.localScale;

        Sequence seq = DOTween.Sequence();

        // Dip DOWN (impact absorption)
        seq.Append(
            rectTransform.DOLocalMoveY(startPos.y - dipAmount, impactDuration)
                .SetEase(Ease.OutQuad)
        );

        // Reverse pop (squash inward)
        seq.Join(
            rectTransform.DOScale(startScale * reversePopScale, impactDuration)
                .SetEase(Ease.OutQuad)
        );

        // Settle back smoothly
        seq.Append(
            rectTransform.DOLocalMoveY(startPos.y, settleDuration)
                .SetEase(Ease.OutQuad)
        );

        seq.Join(
            rectTransform.DOScale(startScale, settleDuration)
                .SetEase(Ease.OutQuad)
        );

        // Hard reset safety
        seq.OnComplete(() =>
        {
            rectTransform.localPosition = startPos;
            rectTransform.localScale = startScale;
        });
    }

    // ---------- MULTIPLIER (NO ANIMATION) ----------

    public void SetMultiplier(float value)
    {
        multiplierValue = value;

        if (multiplierText != null)
        {
            multiplierText.text = $"{multiplierValue:F1}x";
        }
    }

    public float GetMultiplier()
    {
        return multiplierValue;
    }

    // ---------- RESET ----------

    public void ResetState()
    {
        rectTransform?.DOKill();

        if (rectTransform != null)
        {
            rectTransform.localPosition = rectTransform.localPosition;
            rectTransform.localScale = Vector3.one;
        }
    }

    void OnDestroy()
    {
        rectTransform?.DOKill();
    }
}
