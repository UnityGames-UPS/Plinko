using UnityEngine;
using DG.Tweening;
using UnityEngine.UI;

public class PinkoPegHitAnimation : MonoBehaviour
{
    [Header("Wobble Settings")]
    [SerializeField] private float wobbleAmount = 0.1f;
    [SerializeField] private float wobbleDuration = 0.2f;
    [SerializeField] private int wobbleVibrato = 8;

    [Header("Pop Effect Settings")]
    [SerializeField] private Image popEffectImage;
    [SerializeField] private float popScaleMultiplier = 1.2f;
    [SerializeField] private float popFadeDuration = 0.4f;
    [SerializeField] private float popScaleDuration = 0.3f;
    [SerializeField] private AnimationCurve popScaleCurve = AnimationCurve.EaseInOut(0, 0, 1, 1);

    private RectTransform rectTransform;
    private RectTransform popRectTransform;
    private Vector3 originalPegScale;

    private void Awake()
    {
        rectTransform = GetComponent<RectTransform>();

        if (popEffectImage != null)
        {
            popRectTransform = popEffectImage.GetComponent<RectTransform>();
        }
    }

    private void Start()
    {
        // Store the original scale at start
        originalPegScale = rectTransform.localScale;

        // Ensure pop effect child always stays at scale (1,1,1)
        if (popRectTransform != null)
        {
            popRectTransform.localScale = Vector3.one;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ball"))
        {
            PlayHitAnimation();
        }
    }

    public void PlayHitAnimation()
    {
        PlayWobble();
        PlayPopEffect();
    }

    private void PlayWobble()
    {
        // Kill any existing animations
        rectTransform.DOKill();

        // Calculate absolute wobble amount based on original scale
        // This ensures consistent wobble regardless of peg size
        Vector3 absoluteWobble = Vector3.one * wobbleAmount;

        rectTransform.DOPunchScale(absoluteWobble, wobbleDuration, wobbleVibrato, 1f)
            .SetEase(Ease.OutQuad)
            .OnComplete(() =>
            {
                // Force reset to original scale
                rectTransform.localScale = originalPegScale;

                // Ensure child pop effect stays at (1,1,1)
                if (popRectTransform != null)
                {
                    popRectTransform.localScale = Vector3.one;
                }
            });
    }

    private void PlayPopEffect()
    {
        if (popEffectImage == null)
        {
            Debug.LogWarning("Pop effect image not assigned!");
            return;
        }

        popEffectImage.gameObject.SetActive(true);

        // CRITICAL: Always keep pop effect at scale (1,1,1)
        // The pop effect is a CHILD, so it should always be at local scale 1,1,1
        popRectTransform.localScale = Vector3.one;

        // Set initial alpha
        Color startColor = popEffectImage.color;
        startColor.a = 0.12f;
        popEffectImage.color = startColor;

        // Kill any existing pop animations
        popRectTransform.DOKill();
        popEffectImage.DOKill();

        // Target scale for pop (from 1,1,1 to popScaleMultiplier)
        Vector3 targetScale = Vector3.one * popScaleMultiplier;

        Sequence popSequence = DOTween.Sequence();

        // Scale from (1,1,1) to target
        popSequence.Join(
            popRectTransform.DOScale(targetScale, popScaleDuration)
                .SetEase(popScaleCurve)
        );

        // Fade out
        popSequence.Join(
            popEffectImage.DOFade(0f, popFadeDuration)
                .SetEase(Ease.OutQuad)
        );

        popSequence.OnComplete(() =>
        {
            popEffectImage.gameObject.SetActive(false);
            // Reset to (1,1,1) for next time
            popRectTransform.localScale = Vector3.one;
        });
    }

    // Method to update original scale when board is rebuilt
    public void UpdateOriginalScale()
    {
        if (rectTransform != null)
        {
            originalPegScale = rectTransform.localScale;

            // Always ensure pop effect child is at (1,1,1)
            if (popRectTransform != null)
            {
                popRectTransform.localScale = Vector3.one;
            }
        }
    }
}