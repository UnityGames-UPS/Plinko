﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

public class PlinkoBallLauncher : MonoBehaviour
{
    [Header("References")]
    public List<GameObject> ballPool; // Assign 10 balls in inspector
    public PlinkoBoardController boardController;
    public Transform spawnTransform;
    public PlinkoPathCalculator pathCalculator;

    [Header("UI")]
    public Button dropButton;

    [Header("Physics")]
    public float baseGravityScale = 1.5f;

    [Header("Ball Scaling")]
    public float ballScaleAt8Rows = 1.0f;
    public float ballScaleAt16Rows = 0.6f;

    [Header("Multi-Ball Settings")]
    public int maxActiveBalls = 10;

    private List<Transform> activeCatchers = new List<Transform>();
    private Vector3 initialBallPosition;
    private int currentRows = 8;
    private int activeBallCount = 0;
    private HashSet<GameObject> ballsInUse = new HashSet<GameObject>();

    void Start()
    {
        if (pathCalculator == null)
        {
            pathCalculator = gameObject.AddComponent<PlinkoPathCalculator>();
        }

        // Validate ball pool
        if (ballPool == null || ballPool.Count == 0)
        {
            Debug.LogError("Ball pool not assigned! Please assign 10 balls in the inspector.");
            return;
        }

        // Initialize all balls in pool
        foreach (GameObject ball in ballPool)
        {
            if (ball == null) continue;

            Rigidbody2D rb = ball.GetComponent<Rigidbody2D>();
            PlinkoBallController controller = ball.GetComponent<PlinkoBallController>();

            if (rb == null)
            {
                Debug.LogError($"Ball {ball.name} missing Rigidbody2D!");
                continue;
            }

            if (controller == null)
            {
                Debug.LogError($"Ball {ball.name} missing PlinkoBallController!");
                continue;
            }

            // Disable physics initially
            rb.simulated = false;
            ball.SetActive(false);
        }

        if (spawnTransform != null)
        {
            initialBallPosition = spawnTransform.position;
        }
        else
        {
            Debug.LogError("Spawn transform not assigned!");
            initialBallPosition = Vector3.zero;
        }

        if (dropButton != null)
        {
            dropButton.onClick.AddListener(OnDropButtonClicked);
        }

        // IMPORTANT: Update catchers BEFORE scaling balls
        UpdateActiveCatchers();

        // Now update ball scale with correct row count
        UpdateBallScale();
    }

    void UpdateActiveCatchers()
    {
        activeCatchers.Clear();

        if (boardController != null && boardController.catchers.Count > 0)
        {
            foreach (Transform catcher in boardController.catchers)
            {
                if (catcher.gameObject.activeSelf)
                {
                    activeCatchers.Add(catcher);
                }
            }
        }

        Debug.Log($"Active catchers: {activeCatchers.Count}");
    }

    void UpdateBallScale()
    {
        if (ballPool == null || ballPool.Count == 0) return;

        // Get current rows from board controller if available
        if (boardController != null)
        {
            currentRows = boardController.GetCurrentRows();
        }
        else
        {
            // Fallback: use active catchers count
            currentRows = Mathf.Max(activeCatchers.Count - 1, 8);
        }

        // Clamp to valid range
        currentRows = Mathf.Clamp(currentRows, 8, 16);

        float t = Mathf.InverseLerp(8, 16, currentRows);
        float targetScale = Mathf.Lerp(ballScaleAt8Rows, ballScaleAt16Rows, t);

        // Update scale for all balls in pool
        foreach (GameObject ball in ballPool)
        {
            if (ball != null)
            {
                ball.transform.localScale = Vector3.one * targetScale;
            }
        }

        Debug.Log($"Ball scale: {targetScale:F2} for {currentRows} rows (active catchers: {activeCatchers.Count})");
    }

    public void OnDropButtonClicked()
    {
        // Check if we have available balls
        if (activeBallCount >= maxActiveBalls)
        {
            Debug.Log("All balls in use! Wait for balls to finish.");
            if (dropButton != null)
            {
                dropButton.interactable = false;
            }
            return;
        }

        // Find next available ball
        GameObject availableBall = GetAvailableBall();
        if (availableBall == null)
        {
            Debug.LogError("No available balls in pool!");
            return;
        }

        DropBall(availableBall);
    }

    GameObject GetAvailableBall()
    {
        foreach (GameObject ball in ballPool)
        {
            if (ball != null && !ballsInUse.Contains(ball))
            {
                return ball;
            }
        }
        return null;
    }

    void DropBall(GameObject ball)
    {
        UpdateActiveCatchers();

        if (activeCatchers.Count == 0)
        {
            Debug.LogError("No active catchers!");
            return;
        }

        // Pick random target
        int randomIndex = Random.Range(0, activeCatchers.Count);
        Transform targetCatcher = activeCatchers[randomIndex];

        Debug.Log($"Dropping ball {ball.name} - Target: {targetCatcher.name} (Index {randomIndex})");

        // Calculate path
        List<List<Vector2>> pegRows = pathCalculator.GetPegRowsFromBoard(boardController);
        List<Vector2> calculatedPath = pathCalculator.CalculatePath(
            initialBallPosition,
            targetCatcher,
            pegRows
        );

        // Reset ball position
        ball.transform.position = initialBallPosition;
        ball.transform.rotation = Quaternion.identity;
        ball.SetActive(true);

        // Setup physics
        Rigidbody2D ballRb = ball.GetComponent<Rigidbody2D>();
        if (ballRb != null)
        {
            ballRb.bodyType = RigidbodyType2D.Dynamic;
            ballRb.constraints = RigidbodyConstraints2D.None;
            ballRb.linearVelocity = Vector2.zero;
            ballRb.angularVelocity = 0;
            ballRb.gravityScale = baseGravityScale;
            ballRb.linearDamping = 0.3f;
            ballRb.angularDamping = 0.5f;
            ballRb.simulated = true;
            ballRb.WakeUp();

            // Set physics material if not already set
            if (ballRb.sharedMaterial == null)
            {
                PhysicsMaterial2D bouncyMaterial = new PhysicsMaterial2D
                {
                    bounciness = 0.2f,
                    friction = 0.1f
                };
                ballRb.sharedMaterial = bouncyMaterial;
            }
        }

        // Initialize ball controller
        PlinkoBallController ballController = ball.GetComponent<PlinkoBallController>();
        if (ballController != null)
        {
            // Remove old listener if exists
            ballController.onBallCaught -= OnBallLanded;

            // Add new listener
            ballController.onBallCaught += OnBallLanded;

            // Initialize with path
            ballController.Initialize(targetCatcher.name, calculatedPath);
        }

        // Track this ball
        ballsInUse.Add(ball);
        activeBallCount++;

        Debug.Log($"Active balls: {activeBallCount}/{maxActiveBalls}");

        // Update button state
        UpdateButtonState();
    }

    void OnBallLanded(int catcherIndex, GameObject landedBall)
    {
        Debug.Log($"Ball {landedBall.name} landed in catcher: {catcherIndex}");

        if (landedBall != null && ballsInUse.Contains(landedBall))
        {
            // Ball will be disabled by catcher trigger, just schedule reset
            StartCoroutine(ResetBallAfterDelay(landedBall, 1.5f));
        }

        // TODO: Backend integration here
        // Get multiplier from catcher and send to backend
        // PlinkoCatcherAnimation catcher = GetCatcherByIndex(catcherIndex);
        // float multiplier = catcher.GetMultiplier();
        // SendResultToBackend(catcherIndex, multiplier);
    }

    System.Collections.IEnumerator ResetBallAfterDelay(GameObject ball, float delay)
    {
        yield return new WaitForSeconds(delay);

        if (ball != null)
        {
            Rigidbody2D rb = ball.GetComponent<Rigidbody2D>();
            if (rb != null)
            {
                rb.simulated = false;
                rb.linearVelocity = Vector2.zero;
                rb.angularVelocity = 0;
            }

            ball.transform.position = initialBallPosition;
            ball.transform.rotation = Quaternion.identity;

            // Make sure ball is disabled (catcher should have already done this)
            if (ball.activeSelf)
            {
                ball.SetActive(false);
            }

            // Remove from active tracking
            ballsInUse.Remove(ball);
            activeBallCount--;

            Debug.Log($"Ball reset. Active balls: {activeBallCount}/{maxActiveBalls}");

            // Update button state
            UpdateButtonState();
        }
    }

    void UpdateButtonState()
    {
        if (dropButton != null)
        {
            // Button is interactable if we have available balls
            dropButton.interactable = (activeBallCount < maxActiveBalls);
        }
    }

    public void OnBoardRebuilt()
    {
        UpdateActiveCatchers();
        UpdateBallScale();
    }

    void OnDestroy()
    {
        if (dropButton != null)
        {
            dropButton.onClick.RemoveListener(OnDropButtonClicked);
        }

        // Clean up all ball controllers
        if (ballPool != null)
        {
            foreach (GameObject ball in ballPool)
            {
                if (ball != null)
                {
                    PlinkoBallController controller = ball.GetComponent<PlinkoBallController>();
                    if (controller != null)
                    {
                        controller.onBallCaught -= OnBallLanded;
                    }
                }
            }
        }
    }
}