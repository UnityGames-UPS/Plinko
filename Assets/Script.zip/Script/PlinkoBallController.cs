using UnityEngine;
using System;
using System.Collections.Generic;

public class PlinkoBallController : MonoBehaviour
{
    [Header("Physics Settings")]
    public float baseGravityScale = 1.5f;
    public float fallSpeed = 4f;
    public float maxSpeed = 8f;

    [Header("Path Following")]
    public float pathFollowStrength = 20f;
    public float nextPointThreshold = 0.3f;
    public float finalApproachDistance = 2f;
    public bool visualizePath = true;

    [Header("Collision Response")]
    public float pegBounceReduction = 0.3f;
    public float pegPushForce = 1.5f;

    // Events - now includes the ball GameObject reference
    public event Action<int, GameObject> onBallCaught;
    public event Action<GameObject> onPegHit;

    private Rigidbody2D rb;
    private string targetCatcherName;
    private List<Vector2> calculatedPath;
    private int currentPathIndex = 0;
    private bool isFollowingPath = false;
    private int pegCollisions = 0;
    private HashSet<Collider2D> hitPegs = new HashSet<Collider2D>();
    private Vector2 lastPosition;
    private bool inFinalApproach = false;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        if (rb != null)
        {
            rb.gravityScale = baseGravityScale;

            if (rb.sharedMaterial == null)
            {
                PhysicsMaterial2D bouncyMaterial = new PhysicsMaterial2D
                {
                    bounciness = 0.2f,
                    friction = 0.1f
                };
                rb.sharedMaterial = bouncyMaterial;
            }
        }
        else
        {
            Debug.LogError($"Ball {gameObject.name} missing Rigidbody2D!");
        }
    }

    public void Initialize(string targetCatcher, List<Vector2> path)
    {
        targetCatcherName = targetCatcher;
        calculatedPath = path;
        currentPathIndex = 0;
        isFollowingPath = true;
        inFinalApproach = false;
        pegCollisions = 0;
        hitPegs.Clear();
        lastPosition = transform.position;

        Debug.Log($"Ball {gameObject.name} initialized - Target: {targetCatcher}, Path points: {path.Count}");
    }

    void FixedUpdate()
    {
        if (!isFollowingPath || calculatedPath == null || calculatedPath.Count == 0)
            return;

        if (currentPathIndex >= calculatedPath.Count)
        {
            isFollowingPath = false;
            return;
        }

        Vector2 currentPos = transform.position;
        Vector2 targetPoint = calculatedPath[currentPathIndex];
        float distanceToTarget = Vector2.Distance(currentPos, targetPoint);

        Vector2 finalTarget = calculatedPath[calculatedPath.Count - 1];
        float distanceToFinal = Vector2.Distance(currentPos, finalTarget);

        if (distanceToFinal < finalApproachDistance && !inFinalApproach)
        {
            inFinalApproach = true;
        }

        if (distanceToTarget > nextPointThreshold)
        {
            Vector2 direction = (targetPoint - currentPos).normalized;

            if (inFinalApproach)
            {
                Vector2 toFinal = (finalTarget - currentPos).normalized;
                Vector2 desiredVelocity = toFinal * fallSpeed * 1.5f;
                rb.linearVelocity = Vector2.Lerp(rb.linearVelocity, desiredVelocity, Time.fixedDeltaTime * pathFollowStrength);
            }
            else
            {
                Vector2 desiredVelocity = direction * fallSpeed;
                desiredVelocity.y -= baseGravityScale;
                rb.linearVelocity = Vector2.Lerp(rb.linearVelocity, desiredVelocity, Time.fixedDeltaTime * pathFollowStrength);
            }

            if (rb.linearVelocity.magnitude > maxSpeed)
            {
                rb.linearVelocity = rb.linearVelocity.normalized * maxSpeed;
            }
        }
        else
        {
            currentPathIndex++;
            if (currentPathIndex < calculatedPath.Count)
            {
                Debug.Log($"Ball {gameObject.name} reached waypoint {currentPathIndex}/{calculatedPath.Count}");
            }
        }

        float targetAngle = Mathf.Atan2(rb.linearVelocity.y, rb.linearVelocity.x) * Mathf.Rad2Deg;
        float currentAngle = transform.eulerAngles.z;
        float newAngle = Mathf.LerpAngle(currentAngle, targetAngle, Time.fixedDeltaTime * 5f);
        transform.rotation = Quaternion.Euler(0, 0, newAngle);

        lastPosition = currentPos;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Peg"))
        {
            if (!hitPegs.Contains(collision.collider))
            {
                hitPegs.Add(collision.collider);
                pegCollisions++;

                onPegHit?.Invoke(collision.gameObject);

                rb.linearVelocity *= (1f - pegBounceReduction);

                Vector2 pushDir = (transform.position - collision.transform.position).normalized;
                rb.AddForce(pushDir * pegPushForce, ForceMode2D.Impulse);
            }
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Catcher"))
        {
            HandleBallCaught(collision);
        }
    }

    void HandleBallCaught(Collider2D catcher)
    {
        isFollowingPath = false;
        int actualCatcherIndex = ParseCatcherIndex(catcher.name);
        bool hitTarget = (catcher.name == targetCatcherName);

        Debug.Log($"Ball {gameObject.name} caught! Collisions: {pegCollisions}, Catcher: {catcher.name}, " +
                  $"Target: {targetCatcherName}, HIT: {hitTarget}");

        if (rb != null)
        {
            rb.linearVelocity = Vector2.zero;
            rb.angularVelocity = 0;
        }

        // Pass both catcher index AND this ball GameObject
        onBallCaught?.Invoke(actualCatcherIndex, gameObject);
    }

    int ParseCatcherIndex(string catcherName)
    {
        string numberPart = catcherName.Replace("Catchers", "");
        if (int.TryParse(numberPart, out int index))
            return index;

        Debug.LogWarning($"Could not parse catcher index from: {catcherName}");
        return -1;
    }

    void OnDrawGizmos()
    {
        if (!visualizePath || calculatedPath == null || calculatedPath.Count == 0)
            return;

        Gizmos.color = Color.cyan;
        for (int i = 0; i < calculatedPath.Count - 1; i++)
        {
            Gizmos.DrawLine(calculatedPath[i], calculatedPath[i + 1]);
        }

        for (int i = 0; i < calculatedPath.Count; i++)
        {
            if (i == currentPathIndex)
            {
                Gizmos.color = Color.green;
                Gizmos.DrawWireSphere(calculatedPath[i], 0.2f);
            }
            else if (i < currentPathIndex)
            {
                Gizmos.color = Color.gray;
                Gizmos.DrawSphere(calculatedPath[i], 0.1f);
            }
            else
            {
                Gizmos.color = Color.yellow;
                Gizmos.DrawSphere(calculatedPath[i], 0.15f);
            }
        }

        if (currentPathIndex < calculatedPath.Count)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawLine(transform.position, calculatedPath[currentPathIndex]);
        }
    }

    public int GetPegCollisions() => pegCollisions;
    public string GetTargetCatcherName() => targetCatcherName;
}