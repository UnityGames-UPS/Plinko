﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;

public class PlinkoBoardController : MonoBehaviour
{
    [Header("Pyramid Settings")]
    public int startPegCount = 3; // First row pegs
    private const int MAX_ROWS = 16;

    [Header("Peg Settings")]
    public GameObject pegPrefab;
    public float basePegSize = 0.25f;
    public float baseXSpacing = 1.2f;
    public float topPadding = 0.5f;

    [Header("Anchors")]
    public Transform topAnchor;
    public Transform bottomAnchor;
    public BoxCollider2D fitArea;

    [Header("Catchers (17 objects)")]
    public List<Transform> catchers; // assign 17 individually

    [Header("Catcher Y Offset Scaling")]
    public float baseYOffsetAt8Rows = -0.69f;
    public float yOffsetStepPerRow = 0.09f;
    public float baseCatcherHeight = 1f;
    public float heightScaleFactor = 0.92f;

    [Header("UI")]
    public TMP_Dropdown rowsDropdown;
    public Canvas mainCanvas;

    [Header("Ball Launcher Reference")]
    public PlinkoBallLauncher ballLauncher;

    [Header("Limits")]
    public float minScale = 0.4f;

    // Object Pool
    private List<GameObject> pegPool = new();
    private int currentRows = 8;
    private bool isRebuilding = false;

    void Start()
    {
        // Initialize object pool
        InitializePegPool();

        // Setup dropdown options (8-16)
        if (rowsDropdown != null)
        {
            rowsDropdown.ClearOptions();
            List<string> options = new List<string>();
            for (int i = 8; i <= 16; i++)
            {
                options.Add(i.ToString());
            }
            rowsDropdown.AddOptions(options);
            rowsDropdown.value = 0; // Default to 8
            rowsDropdown.onValueChanged.AddListener(OnRowsChanged);
        }

        // Initial build
        currentRows = 8;
        Rebuild();
    }

    void InitializePegPool()
    {
        if (!pegPrefab) return;

        // Calculate total pegs needed for 16 rows
        int totalPegsNeeded = 0;
        for (int row = 0; row < MAX_ROWS; row++)
        {
            totalPegsNeeded += startPegCount + row;
        }

        // Create all pegs and add to pool
        for (int i = 0; i < totalPegsNeeded; i++)
        {
            GameObject peg = Instantiate(pegPrefab, transform);
            peg.SetActive(false);
            pegPool.Add(peg);
        }

        Debug.Log($"Object Pool initialized with {totalPegsNeeded} pegs");
    }

    void OnRowsChanged(int dropdownIndex)
    {
        if (isRebuilding) return;

        currentRows = 8 + dropdownIndex;
        StartCoroutine(RebuildWithCanvasRefresh());
    }

    IEnumerator RebuildWithCanvasRefresh()
    {
        isRebuilding = true;

        // Rebuild the board
        Rebuild();

        // Wait for end of frame
        yield return new WaitForEndOfFrame();

        // Force canvas rebuild
        if (mainCanvas != null)
        {
            Canvas.ForceUpdateCanvases();
            mainCanvas.enabled = false;
            mainCanvas.enabled = true;
            LayoutRebuilder.ForceRebuildLayoutImmediate(mainCanvas.GetComponent<RectTransform>());
        }

        // Notify ball launcher that board was rebuilt
        if (ballLauncher != null)
        {
            ballLauncher.OnBoardRebuilt();
        }

        // Update peg animation original scales
        UpdateAllPegAnimationScales();

        isRebuilding = false;
    }

    public void Rebuild()
    {
        if (!pegPrefab || !topAnchor || !bottomAnchor || catchers.Count == 0)
            return;

        DisableAllPegs();
        GeneratePyramidAndCatchers();

        // Update peg scales after rebuild
        UpdateAllPegAnimationScales();
    }

    void DisableAllPegs()
    {
        foreach (GameObject peg in pegPool)
        {
            peg.SetActive(false);
        }
    }

    void GeneratePyramidAndCatchers()
    {
        // ---------- WIDTH FIT ----------
        Bounds bounds = fitArea.bounds;
        float maxWidth = bounds.size.x * 0.95f;
        int lastRowPegCount = startPegCount + currentRows - 1;
        float requiredWidth = lastRowPegCount * baseXSpacing;
        float scale = Mathf.Max(maxWidth / requiredWidth, minScale);

        float pegSize = basePegSize * scale;
        float xSpacing = baseXSpacing * scale;

        // ---------- HEIGHT FIT ----------
        float topY = topAnchor.position.y - topPadding;
        float bottomY = bottomAnchor.position.y;
        float usableHeight = Mathf.Abs(topY - bottomY);
        float ySpacing = usableHeight / (currentRows - 1);

        Vector2 center = new Vector2(topAnchor.position.x, topY);

        // ---------- GENERATE PEGS FROM POOL ----------
        int poolIndex = 0;
        for (int row = 0; row < currentRows; row++)
        {
            int pegCount = startPegCount + row;
            float rowWidth = (pegCount - 1) * xSpacing;
            float startX = center.x - rowWidth / 2f;
            float y = center.y - row * ySpacing;

            for (int i = 0; i < pegCount; i++)
            {
                if (poolIndex >= pegPool.Count)
                {
                    Debug.LogWarning("Ran out of pegs in pool!");
                    break;
                }

                GameObject peg = pegPool[poolIndex];
                poolIndex++;

                Vector2 pos = new(startX + i * xSpacing, y);
                peg.transform.position = pos;
                peg.transform.localScale = Vector3.one * pegSize;
                peg.SetActive(true);
            }
        }

        // ---------- ALIGN CATCHERS ----------
        AlignCatchers(lastRowPegCount, center.x, xSpacing, pegSize);
    }

    void AlignCatchers(int lastRowPegCount, float centerX, float xSpacing, float pegSize)
    {
        int needed = currentRows + 1;
        int total = catchers.Count;

        // Disable all first
        for (int i = 0; i < total; i++)
            catchers[i].gameObject.SetActive(false);

        int startIndex = (total - needed) / 2;

        float pegRowSpan = (lastRowPegCount - 1) * xSpacing;
        float leftmostPegX = centerX - pegRowSpan / 2f;
        float rightmostPegX = centerX + pegRowSpan / 2f;

        float leftEdge = leftmostPegX;
        float rightEdge = rightmostPegX;
        float totalWidth = rightEdge - leftEdge;
        float catcherWidth = totalWidth / needed;

        int rowsAboveBase = Mathf.Max(0, currentRows - 8);
        float dynamicHeight = baseCatcherHeight * Mathf.Pow(heightScaleFactor, rowsAboveBase);
        float dynamicYOffset = baseYOffsetAt8Rows + (rowsAboveBase * yOffsetStepPerRow);

        for (int i = 0; i < needed; i++)
        {
            int index = startIndex + i;
            if (index < 0 || index >= total) continue;

            Transform box = catchers[index];
            box.gameObject.SetActive(true);

            float x = leftEdge + (i * catcherWidth) + (catcherWidth / 2f);
            float y = bottomAnchor.position.y + dynamicYOffset;

            box.position = new Vector2(x, y);
            box.localScale = new Vector3(catcherWidth * 0.88f, dynamicHeight, 1f);
        }
    }

    
    void UpdateAllPegAnimationScales()
    {
        foreach (GameObject peg in pegPool)
        {
            if (peg != null && peg.activeSelf)
            {
                PinkoPegHitAnimation animation = peg.GetComponent<PinkoPegHitAnimation>();
                if (animation != null)
                {
                    animation.UpdateOriginalScale();
                }
            }
        }

        Debug.Log("Updated original scales for all active pegs");
    }

    public int GetCurrentRows()
    {
        return currentRows;
    }

    void OnDestroy()
    {
        foreach (GameObject peg in pegPool)
        {
            if (peg != null)
            {
                Destroy(peg);
            }
        }
        pegPool.Clear();

        Debug.Log("Peg pool destroyed and cleared");
    }

    void OnDisable()
    {
        DisableAllPegs();
    }
}